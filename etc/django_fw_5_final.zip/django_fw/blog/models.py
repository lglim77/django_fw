from django.db import models
from django.utils import timezone
from django import forms

def min_length_4_validator(value):
    if len(value) < 4:
        raise forms.ValidationError('4글자 이상 입력해 주세요')

class Post(models.Model):
    #작성자
    author = models.ForeignKey('auth.user')
    #글제목
    title = models.CharField(max_length=200,validators=[min_length_4_validator])
    #글내용
    text = models.TextField()
    #글생성날짜
    created_date = models.DateTimeField(default=timezone.now)
    #글게시날짜
    published_date = models.DateTimeField(blank=True,null=True)
    #새로운 컬럼을 추가
    #test = models.TextField()


    #글게시날짜를 업데이트 하는 함수
    def publish(self):
        self.published_date = timezone.now()
        self.save()

    def __str__(self):
        return self.title


class Comment(models.Model):
    post = models.ForeignKey('blog.Post', related_name='comments')
    author = models.CharField(max_length=200)
    text = models.TextField()
    created_date= models.DateTimeField(default=timezone.now)
    approved_comment= models.BooleanField(default=False)

    def approve(self):
        self.approved_comment= True
        self.save()

    def __str__(self):
        return self.text